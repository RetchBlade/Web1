<?php

	class Product {

		public $product_id;
		public $short_name;
		public $manufacturer;
		public $unit_price;
		public $vat_rate_percent;

	}

?>
