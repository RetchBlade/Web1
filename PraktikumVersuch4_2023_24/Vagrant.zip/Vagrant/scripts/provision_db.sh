#!/bin/bash

cat /home/vagrant/scripts/prakt.sql | mysql -u root -proot 